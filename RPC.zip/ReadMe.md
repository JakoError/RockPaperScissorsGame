# complie
mkdir build
cd build
cmake ..
make
./RockPaperScissors